import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:ujjwal_test/views/screens/user_list_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _signUpFormKey = GlobalKey<FormState>();
  TextEditingController nameController = TextEditingController();
  TextEditingController jobController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Form(
        key: _signUpFormKey,
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: [
            const SizedBox(
              height: 40,
            ),
            const Text(
              "Full Name",
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            TextFormField(
              controller: nameController,
              decoration: const InputDecoration(
                  border: const OutlineInputBorder(),
                  hintText: "Enter full name"),
              validator: (val) {
                if (val == null || val.isEmpty) {
                  return 'Enter your Name';
                }
                return null;
              },
            ),
            const SizedBox(
              height: 20,
            ),
            const Text(
              "Job Name",
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            TextFormField(
              controller: jobController,
              decoration: const InputDecoration(
                  border: OutlineInputBorder(), hintText: "Enter full name"),
              validator: (val) {
                if (val == null || val.isEmpty) {
                  return 'Enter Job Name';
                }
                return null;
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.all(20),
        // ignore: sort_child_properties_last
        child: ElevatedButton(
          onPressed: () async {
            if (_signUpFormKey.currentState!.validate()) {
              try {
                const snackBar = SnackBar(
                  content: Text('User Registered Sucessfully!'),
                );
                var res = await http
                    .post(Uri.parse("https://reqres.in/api/users"), body: {
                  "name": nameController.text.toString(),
                  "job": jobController.text.toString()
                });
                var data = json.decode(res.body);
                if (res.statusCode == 201) {
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => UserList()));
                }
                print(data);
                // if
              } catch (e) {
                print(e.toString());
              }
            }
          },
          style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10))),
          child: const Text("Submit"),
        ),
        height: 50,
      ),
    );
  }
}
