import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:ujjwal_test/model/user_data_model.dart';
import 'package:http/http.dart' as http;

class UserList extends StatefulWidget {
  const UserList({Key? key}) : super(key: key);

  @override
  State<UserList> createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  Future<UserDataModel>? userFuture;

  Future<UserDataModel> GetData() async {
    final response =
        await http.get(Uri.parse("https://reqres.in/api/users?page=2"));
    var data = json.decode(response.body);
    print(data);

    return UserDataModel.fromJson(data);
  }

  @override
  void initState() {
    userFuture = GetData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text("Profile"),
        ),
        body: FutureBuilder<UserDataModel>(
          future: userFuture,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
            } else if (snapshot.hasData) {
              return ListView.builder(
                  itemCount: snapshot.data!.data!.length,
                  itemBuilder: (context, index) {
                    return Card(
                      shadowColor: Colors.black26,
                      child: ListTile(
                        title: Text(
                            "${snapshot.data!.data![index].firstName} ${snapshot.data!.data![index].lastName}"),
                        subtitle: Text("${snapshot.data!.data![index].email}"),
                        leading: CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(
                              "${snapshot.data!.data![index].avatar}"),
                        ),
                      ),
                    );
                  });
            }
            return const Center(child: CircularProgressIndicator());
          },
        ));
  }
}
